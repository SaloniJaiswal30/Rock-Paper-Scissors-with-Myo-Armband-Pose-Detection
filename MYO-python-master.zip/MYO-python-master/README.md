MYO-python
==========

MYO armband wrapped with python!
