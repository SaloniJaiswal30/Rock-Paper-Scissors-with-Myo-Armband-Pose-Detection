var classmyo_1_1_quaternion =
[
    [ "Quaternion", "classmyo_1_1_quaternion.html#a5429d1748c7a73f804d9e3b80b90f81a", null ],
    [ "Quaternion", "classmyo_1_1_quaternion.html#a501baac47aa2e0dc1d27bc372e2c1af9", null ],
    [ "conjugate", "classmyo_1_1_quaternion.html#a76dc234322c0cdecd0dc87bad8819345", null ],
    [ "normalized", "classmyo_1_1_quaternion.html#a64a28d8f03ae7b391c242489f2b30146", null ],
    [ "operator*", "classmyo_1_1_quaternion.html#a32c9121b395c4da10325006985e3404e", null ],
    [ "operator*=", "classmyo_1_1_quaternion.html#a579a8b4c6fcb2536d22a92893816297a", null ],
    [ "operator=", "classmyo_1_1_quaternion.html#a40a4aceb4f3bdbf7431bcc146888c16e", null ],
    [ "w", "classmyo_1_1_quaternion.html#af217910646003e81f79213d1b0a6aeca", null ],
    [ "x", "classmyo_1_1_quaternion.html#af5d92d6a62da321b85fbf0ed722787c1", null ],
    [ "y", "classmyo_1_1_quaternion.html#a7ed60595d23102df65c3358a8168247b", null ],
    [ "z", "classmyo_1_1_quaternion.html#aac8afbd2f293e19b436117be86a79233", null ],
    [ "rotate", "classmyo_1_1_quaternion.html#a23b8c84385a2486f37abd14a07ee6c65", null ],
    [ "rotate", "classmyo_1_1_quaternion.html#ab2bc198ec59e5e8a29b1ea4445a67f7d", null ]
];