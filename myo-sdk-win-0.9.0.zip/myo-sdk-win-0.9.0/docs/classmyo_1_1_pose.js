var classmyo_1_1_pose =
[
    [ "Type", "classmyo_1_1_pose.html#ae6566276cac4694db8e9e5873c5b0acf", [
      [ "rest", "classmyo_1_1_pose.html#ae6566276cac4694db8e9e5873c5b0acfa125b728e3dc8376156cec932d3f2da8d", null ],
      [ "fist", "classmyo_1_1_pose.html#ae6566276cac4694db8e9e5873c5b0acfa2d06d67dd9d0a4009df0068d3b8751c1", null ],
      [ "waveIn", "classmyo_1_1_pose.html#ae6566276cac4694db8e9e5873c5b0acfa8772c9ed470420242f2b57ab50ca85ee", null ],
      [ "waveOut", "classmyo_1_1_pose.html#ae6566276cac4694db8e9e5873c5b0acfa966e28aa4be4785b7843ab2759b9cc18", null ],
      [ "fingersSpread", "classmyo_1_1_pose.html#ae6566276cac4694db8e9e5873c5b0acfa74e68cdde1d39519b2e922e4538660ea", null ],
      [ "doubleTap", "classmyo_1_1_pose.html#ae6566276cac4694db8e9e5873c5b0acfa9b86768b0d6b9284c502df6cd5aadea3", null ],
      [ "unknown", "classmyo_1_1_pose.html#ae6566276cac4694db8e9e5873c5b0acfab422467f69f329dfe9d2e3f663763e8d", null ]
    ] ],
    [ "Pose", "classmyo_1_1_pose.html#a9327cc0dc167bb95769e4cb702e4950a", null ],
    [ "Pose", "classmyo_1_1_pose.html#a273294f4e6cf6fa9540c9466a9bfe1bd", null ],
    [ "operator!=", "classmyo_1_1_pose.html#afdcb3e3d22c74cfaffd7f0f49dd1b576", null ],
    [ "operator==", "classmyo_1_1_pose.html#a693ce11b0eb9ba63873b4f5ad3bc5311", null ],
    [ "toString", "classmyo_1_1_pose.html#aa0ebf43892a3b293c661b18c058013b6", null ],
    [ "type", "classmyo_1_1_pose.html#a9797babccf953c61b9b464dc494d29dc", null ],
    [ "operator!=", "classmyo_1_1_pose.html#a0033270d28a525dfd0f65acdb17a5ac4", null ],
    [ "operator!=", "classmyo_1_1_pose.html#a160eab5465da08ad9bf830f6d21c4ed9", null ],
    [ "operator<<", "classmyo_1_1_pose.html#af2a9a5957dea26f6185d759ab9e0705e", null ],
    [ "operator==", "classmyo_1_1_pose.html#ab6362ecd71ac5c8abf927d556375450c", null ],
    [ "operator==", "classmyo_1_1_pose.html#a1df7ef36c37e2f89fd405074d32364c0", null ]
];